
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	export interface AppTypes {
		RouteId(): "/(app)" | "/" | "/(app)/patologista" | "/(app)/patologista/home" | "/(app)/patologista/solicitacoes" | "/(app)/patologista/solicitacoes/[id]" | "/(app)/veterinario" | "/(app)/veterinario/home" | "/(app)/veterinario/nova-solicitacao" | "/(app)/veterinario/solicitacoes" | "/(app)/veterinario/solicitacoes/[id]";
		RouteParams(): {
			"/(app)/patologista/solicitacoes/[id]": { id: string };
			"/(app)/veterinario/solicitacoes/[id]": { id: string }
		};
		LayoutParams(): {
			"/(app)": { id?: string };
			"/": { id?: string };
			"/(app)/patologista": { id?: string };
			"/(app)/patologista/home": Record<string, never>;
			"/(app)/patologista/solicitacoes": { id?: string };
			"/(app)/patologista/solicitacoes/[id]": { id: string };
			"/(app)/veterinario": { id?: string };
			"/(app)/veterinario/home": Record<string, never>;
			"/(app)/veterinario/nova-solicitacao": Record<string, never>;
			"/(app)/veterinario/solicitacoes": { id?: string };
			"/(app)/veterinario/solicitacoes/[id]": { id: string }
		};
		Pathname(): "/" | "/patologista" | "/patologista/" | "/patologista/home" | "/patologista/home/" | "/patologista/solicitacoes" | "/patologista/solicitacoes/" | `/patologista/solicitacoes/${string}` & {} | `/patologista/solicitacoes/${string}/` & {} | "/veterinario" | "/veterinario/" | "/veterinario/home" | "/veterinario/home/" | "/veterinario/nova-solicitacao" | "/veterinario/nova-solicitacao/" | "/veterinario/solicitacoes" | "/veterinario/solicitacoes/" | `/veterinario/solicitacoes/${string}` & {} | `/veterinario/solicitacoes/${string}/` & {};
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/robots.txt" | string & {};
	}
}